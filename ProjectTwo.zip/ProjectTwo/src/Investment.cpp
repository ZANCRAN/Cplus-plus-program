/*
 * Investment.cpp
 *
 *  Created on: Aug 12, 2020
 *      Author: ABC
 */

#include <iostream>
#include<iomanip>
using namespace std;

#include "Investment.h"
// default constructor definition
Investment::Investment(){
	// default constructor member's initialization
	 this->m_initialAmount = 0.00;
	 this->m_monthlyDeposit = 0.00;
	 this->m_annualInterest = 0.00;
     this->m_numberOfYear = 0;


}

// constructor with parameters definition
Investment::Investment(double m_initialAmount, double m_monthlyDeposit,double m_annualInterest, int m_numberOfYear){
         // constructor member's initialization
	    this-> m_initialAmount = m_initialAmount;
		this->m_monthlyDeposit = m_monthlyDeposit;
		this->m_annualInterest = m_annualInterest;
	    this->m_numberOfYear = m_numberOfYear;
}

// Mutators definition
void Investment::SetInitialAmount(double m_initialAmount){      // set initial amount
	this->m_initialAmount = m_initialAmount;
}
void Investment::SetMonthlyDeposit(double m_monthlyDeposit){    // set monthly deposit
	this->m_monthlyDeposit = m_monthlyDeposit;
}
void Investment::SetNumberOfYear(int m_numberOfYear){           // set number of year of investment
	this->m_numberOfYear = m_numberOfYear;
}

void Investment::SetAnnualInterest(double m_annualInterest){     // set annual interest
	this->m_annualInterest = m_annualInterest;
}


// Accessors definition
double Investment::GetInitialAmount() const{                   // get the initial amount
	return m_initialAmount;
}
double Investment::GetMonthlyDeposit() const{                  // get the monthly deposit
	return m_monthlyDeposit;
}
double Investment::GetNumberOfYear() const{                    // get the number of year of investment
	return m_numberOfYear;
}
double Investment::GetAnnualInterst() const{                  // get the annual interest
	return m_annualInterest;
}

// output functions allow us to display the monthly detail of the investment and the year summary

void Investment::PrintMonthlyDetail() const{
	// local variables design to compute our investment, variable i used inside the for loop
	int month, i;
	double total, interest, closingBalance;
	month = this->m_numberOfYear * 12;                        // compute the number of year in month
	double initialAmount = this->m_initialAmount;             // initialize the variable to the current object value
	double monthlyDeposit = this->m_monthlyDeposit;           //initialize the variable to the current object value
    // Monthly Investment output header
    cout <<"|Month"<<"\t"<<"|Opening Amount"<<"\t"<<"|Deposit Amount"<<"\t"<<"|Total Invest"<<"\t\t"<<"|Monthly Interest"<<"\t"<<"|Closing Balance|"<<endl;
    // loop through the number of month
	for (i = 1; i <= month; ++i){
		total = initialAmount + monthlyDeposit;                  // compute total deposit
		interest = total * ((this->m_annualInterest/100)/12);    // compute monthly interest
		closingBalance = interest + total;                       // compute closing balance
		// Monthly Investment output based on the calculation
		cout << "   "<<i <<"\t\t"<< initialAmount<<"\t\t"<<monthlyDeposit<<"\t\t"<<total<<"\t\t"<<interest<<"\t\t"<<closingBalance<<endl;
		initialAmount = closingBalance; // reassign the initial amount to the new closing balance
	}


}

void Investment::PrintYearSummary() const{
	// local variables design to compute our investment, variable i used inside the for loop
	int  i;
	double yearEndInterest, yearEndBalance;
	double year = this->m_numberOfYear;                 // initialize the variable to the current object value
	double initialAmount = this->m_initialAmount;       // initialize the variable to the current object value
	double annualDeposit = this->m_monthlyDeposit * 12;  // compute annual monthly deposit
	// Yearly Investment output header
	cout <<"|Year"<<"\t"<<"|Opening Amount"<<"\t"<<"|Deposit Amount"<<"\t"<<"|Year End Interest"<<"|Year End Balance"<<endl;
	// loop through the number of year
	for (i = 1; i <= year; ++i){
		 yearEndInterest = (initialAmount + annualDeposit) * ((this->m_annualInterest)/100);  //compute the year End interest
		 yearEndBalance = initialAmount + annualDeposit + yearEndInterest;                     // compute the year End balance
		 // Yearly Investment output based on the calculation
		 cout << "   "<<i <<"\t\t"<< initialAmount<<"\t\t"<<annualDeposit<<"\t\t"<<yearEndInterest<<"\t\t"<<yearEndBalance<<endl;
		 initialAmount = yearEndBalance;// reassign the initial amount to the new end year balance
	}

}
