/*
 * Investment.h
 *
 *  Created on: Aug 12, 2020
 *      Author: ABC
 */

#ifndef INVESTMENT_H_
#define INVESTMENT_H_

class Investment
{
public:

	Investment(); // Default constructor declaration
	// constructor with parameters
	Investment(double m_initialAmount,double m_monthlyDeposit,double m_annualInterest, int m_numberOfYear);

	// Mutators declarations
	void SetInitialAmount(double m_initialAmount);
	void SetMonthlyDeposit(double m_monthlyDeposit);
	void SetNumberOfYear(int m_numberOfYear);
	void SetAnnualInterest(double m_annualInterest);

	// Accessors declarations
	double GetInitialAmount() const;
	double GetMonthlyDeposit() const;
	double GetAnnualInterst() const;
	double GetNumberOfYear() const;

	// output declaration
	void PrintYearSummary() const;
	void PrintMonthlyDetail() const;

private:
	double m_initialAmount; // initial deposit amount
	double m_monthlyDeposit; // monthly deposit amount
	double m_annualInterest;  // annual interest
	int m_numberOfYear; // number of year of investment
};



#endif /* INVESTMENT_H_ */
