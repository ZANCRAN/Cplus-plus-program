/*
 * main.cpp
 *
 *  Created on: Aug 12, 2020
 *      Author: ABC
 */

// precision for double & error handling
#include <iostream>
#include <stdexcept>
using namespace std;

#include "Investment.h"

int main() {

    char resp;                      // variable help to control flow
	double initialAmount;           // initial amount
	double monthlyDeposit;          // monthly deposit amount
	double annualInterest;          // annual interest
	double numberOfYear;            // number of year of investment
	// first page header
	cout <<"****************************************************************"<<endl;
	cout << "     W E L C O M E   TO     A I R G E A D    B A N K I N G     "<<endl;
	cout <<"****************************************************************"<<endl;
	cout<< "Pressed Enter key to continue........";
	cout << endl;
	std::cin.get();    // pressed Enter key to continue
    resp ='y';  // initialize the answer to continue to y in order to read the first input
    while (resp =='y'){    // loop long as the user print y
         // header to read our investment data
    	cout <<"****************************************************************"<<endl;
    	cout <<"***************************INVESTMENT PLAN**********************"<<endl;
    	cout <<"****************************************************************"<<endl;
    	// Error checking non-negative value
    	try {

    		cout <<"Initial Investment Amount;  $";
    		cin >> initialAmount;                     // read from keyboard initial amount
    		if (initialAmount < 0){
    			throw runtime_error("Value must be positive");
    		}
    		cout <<"Monthly Deposit:  $";
    		cin >> monthlyDeposit; // read from keyboard monthly deposit
    		if (monthlyDeposit < 0){
    		    			throw runtime_error("Value must be positive");
    		 }
    		cout <<"Annual Interest:  %";
    		cin >>annualInterest;                      // read from keyboard annual interest
    		if (annualInterest <= 0){
    		    			throw runtime_error("Value must be positive superior to zero");
    		 }
    		cout<<"Number of years: ";
    		cin>>numberOfYear;                         // read from keyboard number of year of investment
    		if (numberOfYear <= 0){
    		    			throw runtime_error("Value must be positive superior to zero");
    		  }
    		Investment invest (initialAmount, monthlyDeposit, annualInterest, numberOfYear);


    		cout <<endl; // skipped line twice
    		cout <<endl;
    		// header to display monthly investment detail
    		cout <<"            *********************************************************************************"<<endl;
    		cout <<"            *************************** MONTHLY INVESTMENT DETAILS **************************"<<endl;
    		cout <<"            *********************************************************************************"<<endl;
    		invest.PrintMonthlyDetail();  // use the object to call the function to print monthly investment detail
    		cout <<endl;  // skipped line
    		cout << " Want to see year summary of your investment (y/n)?: ";
    		cin >> resp;
    		if (resp == 'y'){

    			// header to display year investment summary
    			cout <<"            *********************************************************************************"<<endl;
    			cout <<"            *************************** YEAR INVESTMENT SUMMARY **************************"<<endl;
    			cout <<"            *********************************************************************************"<<endl;

    			invest.PrintYearSummary(); // use the object to call the function to print the investment year summary
    		}
    		cout <<endl; // skipped line
    		cout <<"Plan to modify your investment feature, press (y) to continue or (n) to quit?: ";
    		cin>>resp;  // read response from keyboard
    		}
    	 	 catch(runtime_error& excpt){

    	 		 cout << excpt.what()<<endl;
    	 		 cout<<"This program cannot not use negative or null value to compute the investment"<<endl;
    	 		 cout<<"log back and enter only positive value "<<endl;

    	  }


    }

    cout <<endl;  // skipped line
    cout <<"T H A N K   Y O U   F O R    U S I N G    O U R    S E R V I C E S"<<endl;  // goodbye

 return 0;
}
